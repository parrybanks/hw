package cs310datastructures;

import java.util.Objects;

/**
 * A class for a stock broker.
 * 
 * @author Jeffrey LaMarche
 * @version 1.0 - June 27, 2019
 * @version 1.01 - Jan 17, 2020 - updates for assignment template
 */
public class Broker
{
    // instance variables
    private String brokerLicense;       // broker license number
    private String firstName;           // broker first name
    private String lastName;            // broker last name
    private String dept;                // broker department number
    private double commissionRate;      // broker commission rate
    
    // constructors

    /**
     *  Default constructor. 
     */
    public Broker()
    {
        brokerLicense = "";
        firstName = "";
        lastName = "";
        dept = "";
        commissionRate = 0.0;
    }

    /**
     * Broker constructor where every instance variable is provided a value.
     * 
     * @param brokerLicense The broker license number.
     * @param firstName The broker first name.
     * @param lastName The broker last name.
     * @param dept The broker department.
     * @param commissionRate The broker commission rate.
     */
    public Broker(String brokerLicense, String firstName, String lastName, 
            String dept, double commissionRate)
    {
        this.brokerLicense = brokerLicense;
        this.firstName = firstName;
        this.lastName = lastName;
        this.dept = dept;
        this.commissionRate = commissionRate;
    }
    
    /**
     * Broker constructor where instance values are set based on an array
     *      of String values
     * 
     * @param brokerValues string array containing values for each broker
     *      data member value
     */
    public Broker(String[] brokerValues)
    {
        brokerLicense = brokerValues[2];
        firstName = brokerValues[3];
        lastName = brokerValues[4];
        dept = brokerValues[5];
        commissionRate = Double.parseDouble(brokerValues[6]);
    }
   
    // getters

    /**
     * Provides access to the broker license value.
     * 
     * @return a string object reference containing the broker license 
     */
    public String getBrokerLicense()
    {
        return brokerLicense;
    }

    /**
     * Provides access to the broker first name.
     * 
     * @return a string object reference containing the broker first name
     */
    public String getFirstName()
    {
        return firstName;
    }

    /**
     * Provides access to the broker last name.
     * 
     * @return a string object reference containing the broker last name
     */
    public String getLastName()
    {
        return lastName;
    }

    /**
     * Returns the broker department.
     * 
     * @return a string object reference containing the broker department
     */
    public String getDept()
    {
        return dept;
    }

    /**
     * Returns the commission rate received by the broker.
     * 
     * @return a double value containing the broker commission rate
     */
    public double getCommissionRate()
    {
        return commissionRate;
    }
    
    // setters

    /**
     * Changes the broker license to a new value.
     * 
     * @param brokerLicense New broker license number.
     */
    public void setBrokerLicense(String brokerLicense)
    {
        this.brokerLicense = brokerLicense;
    }

    /**
     * Changes the broker first name to a new value.
     * 
     * @param firstName New broker first name.
     */
    public void setFirstName(String firstName)
    {
        this.firstName = firstName;
    }

    /**
     * Changes the broker last name to a new value.
     * 
     * @param lastName New broker last name.
     */
    public void setLastName(String lastName)
    {
        this.lastName = lastName;
    }

    /**
     * Changes the broker department to a new value.
     * 
     * @param dept New broker department.
     */
    public void setDept(String dept)
    {
        this.dept = dept;
    }

    /**
     * Changes the broker commission rate to a new value.
     * 
     * @param commissionRate New broker commission rate.
     */
    public void setCommissionRate(double commissionRate)
    {
        this.commissionRate = commissionRate;
    }
    
    // Other methods

    /**
     * Determines whether the license format provided is valid.
     * Valid format: three characters followed by five digits
     * 
     * @return Return true if license format is valid, false otherwise.
     */
    public boolean isValidLicense()
    {
        final int NUMBER_OF_CHARS = 3;
        final int NUMBER_OF_DIGITS = 5;
        final int LICENSE_LENGTH = NUMBER_OF_CHARS + NUMBER_OF_DIGITS;
        final char LOW_VALID_CHAR = 'A';
        final char HIGH_VALID_CHAR = 'Z';
        final char LOW_VALID_DIGIT = '0';
        final char HIGH_VALID_DIGIT = '9';
        
        boolean isValid = true;
        
        if(brokerLicense.length() != LICENSE_LENGTH)
        {
            isValid = false;
        }
        else
        {
            for(int i = 0; i < brokerLicense.length(); i++)
            {
                if(i < NUMBER_OF_CHARS)
                {
                    if(brokerLicense.charAt(i) < LOW_VALID_CHAR || 
                            brokerLicense.charAt(i) > HIGH_VALID_CHAR)
                    {
                        isValid = false;
                    }
                }
                else
                {
                    if(brokerLicense.charAt(i) < LOW_VALID_DIGIT ||
                            brokerLicense.charAt(i) > HIGH_VALID_DIGIT)
                    {
                        isValid = false;
                    }
                }
            }
        }
        
        return isValid;
    }
    
    /**
     * Determines whether the department format provided is valid.
     * Valid format: 7 chars long and contains a dash and digits in the correct
     *               places, and all of the first three digits are 1, 2, or 3
     * 
     * @return Return true if department format is valid, false otherwise.
     */
    public boolean isValidDept()
    {
        final int DASH_LOC = 3;     // location where the hyphen must occur
        final int DEPT_LENGTH = 7;  // length of the department identifier
        final char LOW_START_VALID_DIGIT = '1';
        final char HIGH_START_VALID_DIGIT = '3';
        final char LOW_END_VALID_DIGIT = '0';
        final char HIGH_END_VALID_DIGIT = '9';
        final char DELIMITER = '-';
        
        boolean isValid = true;
        
        if(dept.length() != DEPT_LENGTH)
        {
            isValid = false;
        }
        else
        { 
            for(int i = 0; i < dept.length(); i++)
            {
                if(i < DASH_LOC)
                {
                    if(dept.charAt(i) < LOW_START_VALID_DIGIT ||
                            dept.charAt(i) > HIGH_START_VALID_DIGIT)
                    {
                        isValid = false;
                    }
                }
                else if(i == DASH_LOC)
                {
                    if(dept.charAt(i) != DELIMITER)
                    {
                        isValid = false;
                    }
                }
                else
                {
                    if(dept.charAt(i) < LOW_END_VALID_DIGIT ||
                            dept.charAt(i) > HIGH_END_VALID_DIGIT)
                    {
                        isValid = false;
                    }
                }
            }
        }
        
        return isValid;
    }
    
    /**
     * Provides a string representation of the Broker object
     * 
     * @return a string containing the Broker data members
     */
    // Overriden methods
    @Override
    public String toString()
    {
        return "Broker{" + "brokerLicense = " + brokerLicense + ", firstName = "
                + firstName + ", lastName = " + lastName + ", dept = " + dept +
                ", commissionRate = " + commissionRate + '}';
    }

    /**
     * Determines if a Broker object and another object are equal
     * 
     * @param obj the object to compare a current Broker object with
     * 
     * @return true if the Broker and other object are equal, false otherwise
     */
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        
        if (obj == null)
        {
            return false;
        }
        
        if (getClass() != obj.getClass())
        {
            return false;
        }
        
        final Broker other = (Broker) obj;
        
        if (Double.doubleToLongBits(this.commissionRate) != 
                Double.doubleToLongBits(other.commissionRate))
        {
            return false;
        }
        
        if (!Objects.equals(this.brokerLicense, other.brokerLicense))
        {
            return false;
        }
        
        if (!Objects.equals(this.firstName, other.firstName))
        {
            return false;
        }
        
        if (!Objects.equals(this.lastName, other.lastName))
        {
            return false;
        }
       
        if (!Objects.equals(this.dept, other.dept))
        {
            return false;
        }
        
        return true;
    }

    /**
     * Calculates the hash code value of a Broker object
     * 
     * @return the Broker object hash code
     */
    @Override
    public int hashCode() 
    {
        int hash = 0;
        
        /*
        TODO: You will complete this in assignment five
        */
        
        return hash;
    }
}
