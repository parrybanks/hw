
package cs310datastructures;

public class GoKartStack
{
    private int[] goKartStack;          // array to hold the stack data
    private int topIndex;               // index of the top of the stack
    
    private final int STACK_MAX_SIZE;   // same as the array length
    
    /**
     * Constructor for creating GoKartStack objects. The stack is created to hold
     *      a specific number of go-karts that start with a specified number. The
     *      karts are added such that the highest number is at the bottom, while
     *      the lowest is at the top. So, if there were three karts and the 
     *      starting number is 1, the stack would be built such that it contains
     *      3, 2, 1, where 1 is at the top and 3 is at the bottom.
     * 
     * @param numberGoKarts the number of go-karts that the stack will hold
     * @param startingGoKartNumber the starting number for the go-karts
     */
    public GoKartStack(int numberGoKarts, int startingGoKartNumber)
    {
        STACK_MAX_SIZE = numberGoKarts;
        
        goKartStack = new int[STACK_MAX_SIZE];
        topIndex = -1;
        goKartStack[topIndex + 1] = startingGoKartNumber;
        
    }
    
    public boolean isStackEmpty()
    {
        boolean isStackEmpty = false;
        
        if (topIndex < 0) {
            isStackEmpty = true;
        }
        
        return isStackEmpty;
    }
    
    public boolean isStackFull()
    {
        boolean isStackFull = false;
        
        if (topIndex == goKartStack.length - 1) {
            isStackFull = true;
        }
        
        return isStackFull;
    }
    
    public void push(int goKartNumber)
    {
        if (!isStackFull()) {
        topIndex++;
        goKartStack[topIndex] = goKartNumber;
        }
    }
    
    public int pop()
    {
        int goKart = -1; 
        if (!isStackEmpty()) {
        goKart = goKartStack[topIndex];
        topIndex--;
        }
        
       
        return goKart;
    }
    
    public int peek()
    {
        int goKart = -1;
        
        goKart = goKartStack[topIndex];
        
        return goKart;
    }
}
