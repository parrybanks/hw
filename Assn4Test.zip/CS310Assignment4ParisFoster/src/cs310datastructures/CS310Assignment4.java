package cs310datastructures;

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

/**
 * The program main class that runs the whole program (SOLUTION)
 *
 * @author Jeffrey LaMarche
 * @author THIS SPACE FOR RENT - YOUR NAME HERE! (No really, put your name here)
 * 
 * @version 1.0 Jan-26-2020
 * @version 1.1 Feb-22-2020 Updates for Assignment 4 Template
 */
public class CS310Assignment4
{
    private static final int NUMBER_BASIC_KARTS = 4;
    private static final int BASIC_KARTS_STARTING_NUMBER = 1;
    private static final int NUMBER_RACING_KARTS = 3;
    private static final int RACING_KARTS_STARTING_NUMBER = 5;
    private static final int TOTAL_KARTS
            = NUMBER_BASIC_KARTS + NUMBER_RACING_KARTS;
    private static final double TOP_BROKER_VALUE = 5000000;
    
    private static final String INPUT_FILENAME = "input/assn4input.txt";
    private static final String GO_KART_INPUT_FILENAME = "input/gokartinfo.txt";
    private static final String GO_KART_USAGE_FILENAME
            = "output/gokartUsageReport.txt";

    private static BrokerLog brokerLog = new BrokerLog();
    private static StockTradeLog stockTradeLog = new StockTradeLog();
    private static Report report = new Report();

    private static GoKartUsage goKartUsage = new GoKartUsage(TOTAL_KARTS);
    private static BrokerQueue standardBrokerQueue = new BrokerQueue();
    private static BrokerQueue topBrokerQueue = new BrokerQueue();
    private static GoKartStack basicKartStack
            = new GoKartStack(NUMBER_BASIC_KARTS, BASIC_KARTS_STARTING_NUMBER);
    private static GoKartStack racingKartStack
            = new GoKartStack(NUMBER_RACING_KARTS, RACING_KARTS_STARTING_NUMBER);

    /**
     * The main method for the entire program
     *
     * @param args the command line arguments
     */
    public static void main(String[] args)
    {
        processFile();

        processGoKartInfo();

        createGoKartReport(GO_KART_USAGE_FILENAME);
    }
    
    public static void processGoKartRequest(String license)
    {
        if (stockTradeLog.totalStockTradeValue(license) >= TOP_BROKER_VALUE) {
            racingKartStack.push(RACING_KARTS_STARTING_NUMBER);
            goKartUsage.assignGoKartToBroker(RACING_KARTS_STARTING_NUMBER, license);
             System.out.println(goKartUsage.getBrokerLicenseForGoKart(TOTAL_KARTS)
                  + " has been assigned go-kart number " 
                  + racingKartStack.peek());
        }
        else if (stockTradeLog.totalStockTradeValue(license) < TOP_BROKER_VALUE) {
            System.out.println(standardBrokerQueue.peek() 
                  + " has been assigned go-kart number " 
                  + racingKartStack.peek());
        }
    }

    public static void processGoKartReturn(String license)
    {
        if (stockTradeLog.totalStockTradeValue(license) >= TOP_BROKER_VALUE) {
            System.out.println("Top broker " + topBrokerQueue.toString() );
        }
        if (stockTradeLog.totalStockTradeValue(license) < TOP_BROKER_VALUE) {
            System.out.println("Standard broker " + standardBrokerQueue.toString() );
        }
        System.out.println("has been assigned go-kart number ");
        }
    
    /**
     * Reads in the go-kart input data file and will call the correct methods to
     *      run the go-kart simulation
     * 
     * (DO NOT CHANGE - This method is finished)
     */
    public static void processGoKartInfo()
    {
        File dataFile = new File(GO_KART_INPUT_FILENAME);
        Scanner fileScanner = null;
        String oneLine;
        String[] lineValues;
        int lineCount = 0;

        try
        {
            fileScanner = new Scanner(dataFile);
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File not found exception for file " + e);
            System.exit(1);
        }

        System.out.printf("Reading Go-Kart data from file: %s\n",
                GO_KART_INPUT_FILENAME);

        while (fileScanner.hasNextLine())
        {
            oneLine = fileScanner.nextLine();
            lineValues = oneLine.split(" ");
            lineCount++;

            if (lineValues[0].equals("REQUEST"))
            {
                processGoKartRequest(lineValues[1]);
            }
            else if (lineValues[0].equals("RETURN"))
            {
                processGoKartReturn(lineValues[1]);
            }
            else
            {
                System.out.println("ERROR! Invalid File Format");
            }
        }

        System.out.printf("Done reading file: %d lines read.\n\n", lineCount);
    }

    /**
     * Creates the go-kart usage report 
     * 
     * (DO NOT CHANGE - This method is finished)
     * 
     * @param reportFilename the filename for the generated report
     */
    public static void createGoKartReport(String reportFilename)
    {
        report.generateGoKartReport(goKartUsage, brokerLog, standardBrokerQueue,
                topBrokerQueue, basicKartStack, racingKartStack, TOTAL_KARTS,
                reportFilename);
    }
    
    /**
     * Reads in the input data file and populates the two logs correctly
     * 
     * (DO NOT CHANGE - This method is finished)
     */
    public static void processFile()
    {
        File dataFile = new File(INPUT_FILENAME);
        Scanner fileScanner = null;
        String oneLine;
        String[] lineValues;
        int lineCount = 0;

        try
        {
            fileScanner = new Scanner(dataFile);
        }
        catch (FileNotFoundException e)
        {
            System.out.println("File not found exception for file " + e);
            System.exit(1);
        }

        System.out.printf("\nReading Broker/Stock data from file: %s\n",
                INPUT_FILENAME);

        while (fileScanner.hasNextLine())
        {
            lineCount++;
            oneLine = fileScanner.nextLine();
            lineValues = oneLine.split(",");

            if (lineValues[0].equals("BROKER"))
            {
                if (lineValues[1].equals("ADD"))
                {
                    addBroker(lineValues);
                }
                else if (lineValues[1].equals("DEL"))
                {
                    deleteBroker(lineValues);
                }
                else
                {
                    System.out.println("ERROR! Invalid Broker Option");
                }
            }
            else if (lineValues[0].equals("TRADE"))
            {
                if (lineValues[1].equals("BUY"))
                {
                    addStockTrade(lineValues);
                }
                else if (lineValues[1].equals("SELL"))
                {
                    deleteStockTrade(lineValues);
                }
                else
                {
                    System.out.println("ERROR! Invalid Trade Option");
                }
            }
            else
            {
                System.out.println("ERROR! Invalid File Format");
            }
        }

        System.out.printf("Done reading file: %d lines read.\n\n", lineCount);
    }

    /**
     * Adds a broker object to the broker log if the broker license is unique
     * 
     * (DO NOT CHANGE - This method is finished)
     *
     * @param lineValues a string array containing data for adding a broker to
     * the broker log
     */
    public static void addBroker(String[] lineValues)
    {
        Broker broker = new Broker(lineValues);
        boolean validLicense;
        boolean validDepartment;
        boolean badData = false;
        boolean wasAdded = false;

        validLicense = broker.isValidLicense();
        validDepartment = broker.isValidDept();

        if (!validLicense)
        {
            System.out.println("  ERROR: Broker has invalid license "
                    + broker.getBrokerLicense());
            badData = true;
        }

        if (!validDepartment)
        {
            System.out.println("  ERROR: Broker with license "
                    + broker.getBrokerLicense() + " has invalid department "
                    + broker.getDept());
            badData = true;
        }

        if (brokerLog.isLicenseUnique(broker.getBrokerLicense()))
        {
            wasAdded = brokerLog.addBroker(broker);

            if (!wasAdded)
            {
                System.out.println("  ADD ERROR: An unknown error"
                        + " has occurred!");
                System.out.println("             Broker "
                        + broker.getBrokerLicense()
                        + " will not be added to Broker log");
            }
            else if (badData)
            {
                System.out.println("  ADDED: Broker with license "
                        + broker.getBrokerLicense()
                        + " regardless of data validation errors");
            }
            else
            {
                System.out.println("  ADDED: Broker with license "
                        + broker.getBrokerLicense());
            }
        }
        else
        {
            System.out.println("  ADD ERROR: Broker with license "
                    + broker.getBrokerLicense() + " is not unique (already "
                    + "associated with another Broker)");
            System.out.println("             Broker "
                    + broker.getBrokerLicense()
                    + " will not be added to Broker log");
        }
    }

    /**
     * Adds a stock trade object to the stock trade log if the stock symbol is
     * unique
     * 
     * (DO NOT CHANGE - This method is finished)
     *
     * @param lineValues a string array containing data for adding a stock trade
     * to the stock trade log
     */
    public static void addStockTrade(String[] lineValues)
    {
        StockTrade stock = new StockTrade(lineValues);
        String license = "";
        String symbol = "";
        boolean validStockSymbol;
        boolean validStockPrice;
        boolean validNumberShares;
        boolean uniqueLicense;
        boolean uniqueStockSym;
        boolean badData = false;
        boolean wasAdded = false;

        validStockSymbol = stock.isValidStockSymbol();
        validStockPrice = stock.isValidPrice();
        validNumberShares = stock.isValidWholeShares();

        if (!validStockSymbol)
        {
            System.out.println("    ERROR: StockTrade with Stock symbol "
                    + stock.getStockSymbol() + " has an invalid Stock Symbol");
            badData = true;
        }

        if (!validStockPrice)
        {
            System.out.println("    ERROR: StockTrade with Stock symbol "
                    + stock.getStockSymbol() + " has an invalid Stock Price of "
                    + stock.getPricePerShare());
            badData = true;
        }

        if (!validNumberShares)
        {
            System.out.println("    ERROR: StockTrade with Stock symbol "
                    + stock.getStockSymbol() + " has an invalid Number of Shares"
                    + " of " + stock.getWholeShares());
            badData = true;
        }

        license = stock.getBrokerLicense();
        uniqueLicense = brokerLog.isLicenseUnique(license);

        symbol = stock.getStockSymbol();
        uniqueStockSym = stockTradeLog.isStockSymbolUnique(symbol);

        if (!uniqueLicense)
        {
            if (uniqueStockSym)
            {
                wasAdded = stockTradeLog.addStockTrade(stock);

                if (!wasAdded)
                {
                    System.out.println("  ADD ERROR: The StockTradeLog"
                            + " is full!");
                    System.out.println("             StockTrade "
                            + stock.getStockSymbol()
                            + " will not be added to StockTrade log");
                }
                else if (badData)
                {
                    System.out.println("  ADDED: StockTrade with Stock symbol "
                            + stock.getStockSymbol() + " listed by Broker "
                            + stock.getBrokerLicense()
                            + ", regardless of data errors");
                }
                else
                {
                    System.out.println("  ADDED: StockTrade with Stock symbol "
                            + stock.getStockSymbol() + " listed by Broker "
                            + stock.getBrokerLicense());
                }
            }
            else
            {
                System.out.println("  ADD ERROR: StockTrade with Stock symbol "
                        + stock.getStockSymbol() + " is not unique (already "
                        + "associated with another StockTrade)");
                System.out.println("             StockTrade "
                        + stock.getStockSymbol()
                        + " will not be added to StockTrade log");
            }
        }
        else
        {
            System.out.println("  ADD ERROR: StockTrade with Stock symbol "
                    + stock.getStockSymbol() + " has Broker with license "
                    + stock.getBrokerLicense() + ",");
            System.out.println("           "
                    + "  but there is no such Broker license"
                    + " in the Broker log.");
            System.out.println("             StockTrade "
                    + stock.getStockSymbol()
                    + " will not be added to StockTrade log");
        }
    }

    /**
     * Attempts to delete a broker from the broker log
     *
     * (DO NOT CHANGE - This method is finished)
     * 
     * @param lineValues a string array containing data for deleting a broker
     * from the broker log
     */
    public static void deleteBroker(String[] lineValues)
    {
        System.out.println("  ERROR: Unsupported option! Why are you trying to"
                + " delete in this assignment?");
    }

    /**
     * Attempts to delete a stock trade listing from the stock trade log
     *
     * @param lineValues a string array containing data for deleting a stock
     * trade from the stock trade log
     */
    public static void deleteStockTrade(String[] lineValues)
    {
        System.out.println("  ERROR: Unsupported option! Why are you trying to"
                + " delete in this assignment?");
    }

    /**
     * Creates the broker/stock trade report
     *
     * @param reportFilename the filename for the generated report
     */
    public static void createReport(String reportFilename)
    {
        System.out.println("ERROR: This is not the report you are looking for!");
    }

}
