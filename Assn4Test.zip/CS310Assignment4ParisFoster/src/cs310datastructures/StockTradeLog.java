
package cs310datastructures;

import java.util.ArrayList;

/**
 * This class provides a log of StockTrade objects that are stored in a Java
 *   Collections ArrayList
 * . 
 *   Each StockTrade in the log is unique and associated with a specific Broker
 *   that is in the Broker log.
 * 
 * @author Jeffrey LaMarche
 * @version 1.0 Feb-22-2020
 */
public class StockTradeLog
{
    private ArrayList<StockTrade> stockTradeList;
    
    /**
     * Default constructor for the StockTradeLog class
     */
    public StockTradeLog()
    {
        stockTradeList = new ArrayList<StockTrade>();
    }
    
    /**
     * Allows access to the reference for the entire ArrayList containing
   the currentStock trade log data
     * 
     * @return the reference to the ArrayList storing StockTrade data
     */
    public ArrayList<StockTrade> getStockTradeList()
    {
        return stockTradeList;
    }
    
    /**
     * Adds a new StockTrade object into the log data
     * 
     * @param tradeObj the StockTrade to add to the currentStock trade log
     * 
     * @return true if the currentStock trade was added to the log, false otherwise
     */
    public boolean addStockTrade(StockTrade tradeObj)
    {
        boolean isSuccessful = false;
        
        isSuccessful = stockTradeList.add(tradeObj);
        
        return isSuccessful;
    }
    
    /**
     * Finds a currentStock trade based on a specific currentStock symbol
     * 
     * @param stockSymbol string that contains a currentStock symbol to look for
     * 
     * @return a reference to the StockTrade object found or null if 
     *      there was no match
     */
    public StockTrade findStockTrade(String stockSymbol)
    {
        StockTrade foundTrade = null;
        boolean searching = true;
        int i = 0;
        
        while(searching && i < stockTradeList.size())
        {
            StockTrade currentStock = stockTradeList.get(i);
            
            if(currentStock.getBrokerLicense().equals(stockSymbol))
            {
                foundTrade = currentStock;
                searching = false;
            }
            
            i++;
        }
        
        return foundTrade;
    }
    
    /**
     * Determines whether a particular stock symbol value is already in the 
     *   stock trade log. If the stock symbol is in the log already, 
     *   it is not unique.
     * 
     * @param stockSymbol a string containing the currentStock symbol to 
     *      test for uniqueness
     * 
     * @return true if the currentStock symbol was not located, false otherwise
     */
    public boolean isStockSymbolUnique(String stockSymbol)
    {
        boolean isUnique = true;
        
        StockTrade foundTrade = findStockTrade(stockSymbol);
        
        if(foundTrade != null)
        {
            isUnique = false;
        }
        
        return isUnique;
    }
    
    /**
     * Counts the number of currentStock trades in the log that are located based 
     *      on a specific broker license value.
     * 
     * @param license a string containing the broker license to use when counting
     *      the number of currentStock trades associated with a broker
     * 
     * @return the number of currentStock trades associated with a 
     *      specific broker
     */
    public int numberOfBrokerStockTrades(String license)
    {
        int numberOfTrades = 0;
        
        for(StockTrade currentStock: stockTradeList)
        {
            if(currentStock.getBrokerLicense().equals(license))
            {
                numberOfTrades++;
            }
        }
        
        return numberOfTrades;
    }
    
    /**
     * Calculates the total currentStock trade value for a particular broker
     *      based on their license
     * 
     * @param license a string containing the license of the broker to use in
     *      the calculate of total currentStock trade value
     * 
     * @return the total value of all currentStock trades for a particular broker
     */
    public double totalStockTradeValue(String license)
    {
        double totalValue = 0;
        
        for(StockTrade currentStock: stockTradeList)
        {
            if(currentStock.getBrokerLicense().equals(license))
            {
                double sharePrice = currentStock.getPricePerShare();
                int numShares = currentStock.getWholeShares();
                
                totalValue = totalValue + sharePrice * numShares;
            }
        }
        
        return totalValue;
    }
}
