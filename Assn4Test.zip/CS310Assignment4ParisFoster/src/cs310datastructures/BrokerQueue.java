
package cs310datastructures;

public class BrokerQueue
{
    private BrokerNode queueFront;
    private BrokerNode queueBack;
    private int queueSize;
    
    public BrokerQueue()
    {
        queueFront = null;
        queueBack = null;
    }
    
    public boolean isQueueEmpty()
    {
        if (queueFront == null) {
            return true;
        }
        else {
        
        return false;
        }
    }
    
    public void enqueue(Broker brokerObj)
    {
        BrokerNode newNode = new BrokerNode(brokerObj);
        if (queueBack != null) {
            queueBack.setNextBrokerNode(newNode);
        }
        else {
            queueFront = newNode;
        }
        queueBack = newNode;
        
    }
    
    public Broker dequeue()
    {
        Broker brokerObj = null;
        
        if (queueFront != null) {
            brokerObj = queueFront.getBrokerObj();
            queueFront = queueFront.getNextBrokerNode();
            if (isQueueEmpty())
                queueBack = null;
        }
        else {
            System.out.println("Queue was empty");
        }
        
        return brokerObj;
    }
    
    public Broker peek()
    {
        Broker brokerObj = null; 
        
        BrokerNode newNode = null;
        newNode = new BrokerNode(brokerObj);
        
          if (queueFront != null) { 
            brokerObj = queueFront.getBrokerObj();
         }
        return brokerObj;
    }
}
