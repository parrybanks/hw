
package cs310datastructures;

import java.io.File;
import java.io.PrintWriter;

public class Report
{
    /**
     * Creates a report about go-kart usage 
     * <br><br>
     * <b>WARNING: This is a destructive method. The stack and queue data will 
     *  not be retained after this method is called.</b>
     * 
     * @param goKartUsage contains information about go-karts currently in use
     * @param brokerLog the log of brokers
     * @param standardQueue a queue containing the standard brokers still waiting
     * @param topQueue a queue containing the top brokers still waiting
     * @param basicKarts a stack containing available basic go-karts 
     * @param racingKarts a stack containing available racing go-karts
     * @param totalNumberKarts the total number of go-karts available
     * @param reportFilename the filename where the report will be written
     */
    public void generateGoKartReport(GoKartUsage goKartUsage, 
            BrokerLog brokerLog,BrokerQueue standardQueue, 
            BrokerQueue topQueue, GoKartStack basicKarts,
            GoKartStack racingKarts, int totalNumberKarts, String reportFilename)
    {
        // TODO - complete this method
    }
}
