package cs310datastructures;

/**
 * This class helps track which broker is using a particular go-kart
 * 
 * @author Jeffrey LaMarche
 * @author PARIS FOSTER
 */
public class GoKartUsage
{
    /**
     * List of broker licenses that currently have an assigned go-kart
     */
    private String[] goKartUsageList;

    /**
     * Constructor for GoKartUsage class
     *
     * @param numberGoKarts The number of go-karts to track
     */
    public GoKartUsage(int numberGoKarts)
    {
        goKartUsageList = new String[numberGoKarts];
    }

    /**
     * Assigns a go-kart to a specific Broker
     *
     * @param goKartNumber the go-kart to assign to a broker
     * @param brokerLicense the broker's license
     */
    public void assignGoKartToBroker(int goKartNumber, String brokerLicense)
    {
        if (goKartNumber <= goKartUsageList.length 
              && goKartUsageList[goKartNumber - 1] == null) {
            goKartUsageList[goKartNumber - 1] = brokerLicense;
        }
    }

    /**
     * Gets the broker license associated with a particular go-kart
     *
     * @param goKartNumber the go-kart number to check who is assigned
     *
     * @return the license of the broker currently using a particular go-kart or
     *      null if no one is using the go-kart
     */
    public String getBrokerLicenseForGoKart(int goKartNumber)
    {
        if (goKartUsageList[goKartNumber - 1] == null) {
            return null;
        }
        else {
            return goKartUsageList[goKartNumber];
        }
    }

    /**
     * Disassociates a particular go-kart from a broker
     *
     * @param brokerLicense the license of the broker returning the go-kart
     *
     * @return the go-kart number or -1 if the kart had not been in use
     */
    public int returnGoKart(String brokerLicense)
    {
        int goKartNumber = -1;
        
        for (int i = 0; i < goKartUsageList.length; i++) {
            if (goKartUsageList[i] == brokerLicense) {
                goKartUsageList[i] = null;
                goKartNumber = i;
                break;
            }
        }

        return goKartNumber;
    }
}
