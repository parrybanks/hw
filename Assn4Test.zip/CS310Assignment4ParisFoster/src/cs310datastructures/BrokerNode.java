
package cs310datastructures;

/**
 * This class provides a node for creating a singly linked list containing 
 *   Broker object data. 
 * 
 * @author Jeffrey LaMarche
 * @version 1.0 Jan-26-2020
 */
public class BrokerNode
{
    private Broker brokerObj;
    private BrokerNode nextBrokerNode;

    /**
     * Default constructor for a BrokerNode
     */
    public BrokerNode()
    {
        brokerObj = null;
        nextBrokerNode = null;
    }
    
    /**
     * Constructor that allows assigning the Broker data
     * 
     * @param newBroker the new Broker to insert into the node
     */
    public BrokerNode(Broker newBroker)
    {
        brokerObj = newBroker;
        nextBrokerNode = null;
    }
    
    /**
     * Allows access to the next BrokerNode data (could be null)
     *   (i.e., What the current BrokerNode points to.)
     * 
     * @return the value of next node reference
     */
    public BrokerNode getNextBrokerNode()
    {
        return nextBrokerNode;
    }
    
    /**
     * Allows access to the Broker object data (could be null)
     * 
     * @return the value of the Broker reference
     */
    public Broker getBrokerObj()
    {
        return brokerObj;
    }
    
    /**
     * Allows setting the nextBrokerNode reference to a new value
     * 
     * @param newNextNode the BrokerNode reference to assign as the next link
     *                      (i.e., specify what BrokerNode points to)
     */
    public void setNextBrokerNode(BrokerNode newNextNode)
    {
        nextBrokerNode = newNextNode;
    }
    
    /**
     * Allows setting the Broker object data to a new value
     * 
     * @param newBroker the new Broker reference to assign inside the node
     */
    public void setBrokerObj(Broker newBroker)
    {
        brokerObj = newBroker;
    }
}
