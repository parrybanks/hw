package cs310datastructures;

import java.util.Objects;

/**
 * A class for a stock trade of a broker
 * 
 * @author Jeffrey LaMarche
 * @version 1.0 - June 27, 2019
 * @version 1.01 - Jan 17, 2020 - updates for assignment template
 */
public class StockTrade
{
    // member variables
    private String stockSymbol;     // the symbol for a stock
    private double pricePerShare;   // price for a single share of stock
    private int wholeShares;        // number of shares of stock
    private String brokerLicense;   // license of a broker associated with stock
    private boolean taxable;        // whether the stock transaction is taxable

    // constructors

    /**
     * Default constructor
     */
    public StockTrade()
    {
        stockSymbol = "";
        pricePerShare = 0.0;
        wholeShares = 0;
        brokerLicense = "";
        taxable = false;
    }

    /**
     * Constructor for a Stock Trade object that allows setting all data members
     * 
     * @param stockSymbol the stock symbol for the trade
     * @param pricePerShare the price per share for the trade
     * @param wholeShares the number of whole shares for the trade
     * @param brokerLicense the license of the broker associated with the trade
     * @param taxable whether the trade is taxable
     */
    public StockTrade(String stockSymbol, double pricePerShare, int wholeShares, 
            String brokerLicense, boolean taxable)
    {
        this.stockSymbol = stockSymbol;
        this.pricePerShare = pricePerShare;
        this.wholeShares = wholeShares;
        this.brokerLicense = brokerLicense;
        this.taxable = taxable;
    }
    
    /**
     * Constructor that sets all Stock Trade object values based on 
     *   the contents of a string array
     * 
     * @param stockTradeValues string array containing values for all trade attributes
     */
    public StockTrade(String[] stockTradeValues)
    {
        stockSymbol = stockTradeValues[2];
        pricePerShare = Double.parseDouble(stockTradeValues[3]);
        wholeShares = Integer.parseInt(stockTradeValues[4]);
        brokerLicense = stockTradeValues[5];
        
        if(stockTradeValues[6].equals("Y"))
        {
            taxable = true;
        }
        else
        {
            taxable = false;
        }
    }
    
    // getter methods

    /**
     * Provides access to the stock symbol for a trade
     * 
     * @return a string object reference containing the stock symbol 
     */

    public String getStockSymbol()
    {
        return stockSymbol;
    }

    /**
     * Provides access to the price per share for the trade
     * 
     * @return a double value containing the price per share
     */
    public double getPricePerShare()
    {
        return pricePerShare;
    }

    /**
     * Provides access to the number of whole shares for the trade
     * 
     * @return an integer value containing the number of whole shares
     */
    public int getWholeShares()
    {
        return wholeShares;
    }

    /**
     * Provides access to the broker license associated with a stock trade
     * 
     * @return a string object reference containing the broker license 
     */
    public String getBrokerLicense()
    {
        return brokerLicense;
    }

    /**
     * Provides access to whether the stock trade was taxable
     * 
     * @return true if taxable and false otherwise
     */
    public boolean isTaxable()
    {
        return taxable;
    }
    
    // setter methods

    /**
     * Allows setting the stock symbol for a trade
     * 
     * @param stockSymbol the new stock symbol for the trade
     */

    public void setStockSymbol(String stockSymbol)
    {
        this.stockSymbol = stockSymbol;
    }

    /**
     * Allows setting the price per share for a trade
     * 
     * @param pricePerShare the new price per share of a trade
     */
    public void setPricePerShare(double pricePerShare)
    {
        this.pricePerShare = pricePerShare;
    }

    /**
     * Allows setting the number of whole shares of a trade
     * 
     * @param wholeShares the new number of shares for a trade
     */
    public void setWholeShares(int wholeShares)
    {
        this.wholeShares = wholeShares;
    }

    /**
     * Allows setting the license of a broker associated with a trade
     * 
     * @param brokerLicense the new broker license for the trade
     */
    public void setBrokerLicense(String brokerLicense)
    {
        this.brokerLicense = brokerLicense;
    }

    /**
     * Allows setting the taxable status of a trade
     * 
     * @param taxable true if the trade is taxable and false otherwise
     */
    public void setTaxable(boolean taxable)
    {
        this.taxable = taxable;
    }

    // other methods

    /**
     * Checks whether the trade stock symbol is valid
     * Valid Format: Length of 3 or 4 and all uppercase characters
     * 
     * @return true if the symbol is valid and false otherwise
     */
    public boolean isValidStockSymbol()
    {
        final int MIN_SYMBOL_LENGTH = 3;
        final int MAX_SYMBOL_LENGTH = 4;
        final char LOW_VALID_CHAR = 'A';
        final char HIGH_VALID_CHAR = 'Z';
        
        boolean isValid = true;
        
        if(stockSymbol.length() < MIN_SYMBOL_LENGTH ||
                stockSymbol.length() > MAX_SYMBOL_LENGTH)
        {
            isValid = false;
        }
        else
        {
            for(int i = 0; i < stockSymbol.length(); i++)
            {
                if(stockSymbol.charAt(i) < LOW_VALID_CHAR ||
                        stockSymbol.charAt(i) > HIGH_VALID_CHAR)
                {
                    isValid = false;
                }
            }
        }
        
        return isValid;
    }
    
    /**
     * Checks whether the price of a trade is valid
     * 
     * @return true if the price is valid and false otherwise
     */
    public boolean isValidPrice()
    {
        final double MIN_PRICE_PER_SHARE = 0.0;
        final double MAX_PRICE_PER_SHARE = 1000.0;
        
        boolean isValid = true;
        
        if(pricePerShare < MIN_PRICE_PER_SHARE || 
                pricePerShare > MAX_PRICE_PER_SHARE)
        {
            isValid = false;
        }
        
        return isValid;
    }
    
    /**
     * Checks whether the number of whole shares is valid
     * 
     * @return true if the whole shares is valid and false otherwise
     */
    public boolean isValidWholeShares()
    {
        final int MIN_NUMBER_SHARES = 0;
        final int MAX_NUMBER_SHARES = 100000;
        
        boolean isValid = true;
        
        if(wholeShares < MIN_NUMBER_SHARES || wholeShares > MAX_NUMBER_SHARES)
        {
            isValid = false;
        }
        
        return isValid;
    }
    
    // overriden methods
    
    /**
     * Provides a string representation of the StockTrade object
     * 
     * @return a string containing the StockTrade data members
     */
    @Override
    public String toString()
    {
        return "StockTrade{" + "stockSymbol = " + stockSymbol + 
                ", pricePerShare = " + pricePerShare + ", wholeShares = " 
                + wholeShares + ", brokerLicense = " + brokerLicense + 
                ", taxable = " + taxable + '}';
    }
    
    /**
     * Determines if a StockTrade object and another object are equal
     * 
     * @param obj the object to compare a current StockTrade object with
     * 
     * @return true if the StockTrade and other object are equal, false otherwise
     */
    @Override
    public boolean equals(Object obj)
    {
        if (this == obj)
        {
            return true;
        }
        
        if (obj == null)
        {
            return false;
        }
        
        if (getClass() != obj.getClass())
        {
            return false;
        }
        
        final StockTrade other = (StockTrade) obj;
        
        if (Double.doubleToLongBits(this.pricePerShare) 
                != Double.doubleToLongBits(other.pricePerShare))
        {
            return false;
        }
        
        if (this.wholeShares != other.wholeShares)
        {
            return false;
        }
        
        if (this.taxable != other.taxable)
        {
            return false;
        }
        
        if (!Objects.equals(this.stockSymbol, other.stockSymbol))
        {
            return false;
        }
        
        if (!Objects.equals(this.brokerLicense, other.brokerLicense))
        {
            return false;
        }
        
        return true;
    }
    
    /**
     * Calculates the hash code value of a StockTrade object
     * 
     * @return the StockTrade object hash code
     */
    @Override
    public int hashCode()
    {
        int hash = 0;
        
        /*
        TODO: You will complete this in assignment five
        */
        
        return hash;
    }
}
