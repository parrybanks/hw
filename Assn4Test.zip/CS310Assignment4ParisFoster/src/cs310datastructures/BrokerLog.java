
package cs310datastructures;

import java.util.ArrayList;

/**
 * This class provides a log of Broker objects that are stored in an ArrayList. 
 *   The Broker objects are sorted in ascending order based on their
 *   license number. Broker objects are also unique, based on the license 
 *   number.
 * 
 * @author Jeffrey LaMarche
 * @version 1.0 Feb-22-2020
 */
public class BrokerLog
{
    // update this to be brokerArrayList in the future
    private ArrayList<Broker> brokerList;
    
    /**
     * Default constructor for the BrokerLog class
     */
    public BrokerLog()
    {
        brokerList = new ArrayList<Broker>();
    }
    
    /**
     * Allows obtaining access to the ArrayList reference that contains the 
     *      currentBroker log data (should probably be a copy of the data)
     * 
     * @return an ArrayList reference that contains a sorted list of 
     *      Broker objects
     */
    public ArrayList<Broker> getBrokerList()
    {
        return brokerList;
    }
    
    /**
     * Adds a Broker object to the currentBroker log data
     * 
     * @param brokerObj a Broker object to add to the currentBroker log
     * 
     * @return true if the addition was successful, false otherwise
     */
    public boolean addBroker(Broker brokerObj)
    {
        boolean isSuccessful = false;
        
        brokerList.add(brokerObj);
        isSuccessful = true;
        
        return isSuccessful;
    }
    
    /**
     * Attempts to locate a currentBroker based on a specific license value
     * 
     * @param license the string value of the license to search for
     * 
     * @return a reference to the Broker object found or null if there
     *      was no match
     */
    public Broker findBroker(String license)
    {
        Broker foundBroker = null;
        boolean searching = true;
        int index = 0;
        
        while(searching && index < brokerList.size())
        {
            Broker currentBroker = brokerList.get(index);
            
            if(currentBroker.getBrokerLicense().equals(license))
            {
                foundBroker = currentBroker;
                searching = false;
            }
            
            index++;
        }
        
        return foundBroker;
    }
    
    /**
     * Determines whether a particular license value is already in the 
     *      current Broker log. If the license is in the log already, it 
     *      is not unique.
     * 
     * @param license the string value of the license to test for uniqueness
     * 
     * @return true if the license was not located, false otherwise
     */
    public boolean isLicenseUnique(String license)
    {
        boolean isUnique = true;
        
        Broker foundBroker = findBroker(license);
        
        if(foundBroker != null)
        {
            isUnique = false;
        }
        
        return isUnique;
    }
}
